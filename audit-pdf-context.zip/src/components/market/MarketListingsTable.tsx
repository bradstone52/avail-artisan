import { useRef, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MarketListing } from '@/hooks/useMarketListings';
import { useAuth } from '@/contexts/AuthContext';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { StatusDropdown } from '@/components/market/StatusDropdown';
import { EditMarketPinDialog } from '@/components/market/EditMarketPinDialog';
import { ExternalLink, MapPin, MapPinOff, Hand, Pencil, Copy, Receipt, RotateCcw, ArrowUp, ArrowDown, ArrowUpDown, CheckCircle, Building2, MoreHorizontal } from 'lucide-react';
import { format, differenceInDays, parseISO } from 'date-fns';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { formatSubmarket } from '@/lib/formatters';

export type SortDirection = 'asc' | 'desc' | null;
export type SortableColumn = 'size_sf' | 'warehouse_sf' | 'office_sf' | 'dock_doors' | 'drive_in_doors' | 'power_amps' | 'last_verified_date';

interface MarketListingsTableProps {
  listings: MarketListing[];
  onEdit: (listing: MarketListing) => void;
  onDuplicate?: (listing: MarketListing) => void;
  onRefresh: () => void;
  sortColumn: SortableColumn | null;
  sortDirection: SortDirection;
  onSort: (column: SortableColumn) => void;
  selectedIds?: Set<string>;
  onToggleSelect?: (id: string) => void;
  onToggleSelectAll?: (ids: string[]) => void;
}

function formatSF(sf: number | null): string {
  if (!sf) return '-';
  return sf.toLocaleString();
}

function formatDate(dateStr: string | null): string {
  if (!dateStr) return '-';
  try {
    return format(new Date(dateStr), 'MMM yyyy');
  } catch {
    return dateStr;
  }
}

function formatCurrency(value: string | null): string {
  if (!value) return '-';
  return value;
}

function formatSalePrice(value: string | null): string {
  if (!value) return '-';
  // Parse the number and format as currency without decimals
  const numValue = parseFloat(value.replace(/[^0-9.-]/g, ''));
  if (isNaN(numValue)) return value;
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(numValue);
}

function calculateGrossRate(askRate: string | null, opCosts: string | null): string {
  if (!askRate || !opCosts) return '-';
  
  // Parse numeric values
  const askNum = parseFloat(askRate.replace(/[^0-9.-]/g, ''));
  const opNum = parseFloat(opCosts.replace(/[^0-9.-]/g, ''));
  
  if (isNaN(askNum) || isNaN(opNum)) return '-';
  
  const gross = askNum + opNum;
  return `$${gross.toFixed(2)}`;
}

export function MarketListingsTable({ listings, onEdit, onDuplicate, onRefresh, sortColumn, sortDirection, onSort, selectedIds, onToggleSelect, onToggleSelectAll }: MarketListingsTableProps) {
  const navigate = useNavigate();
  const { session } = useAuth();
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [isHovered, setIsHovered] = useState(false);
  const [selectedRowId, setSelectedRowId] = useState<string | null>(null);
  const [updatingDW, setUpdatingDW] = useState<string | null>(null);
  const [updatingLand, setUpdatingLand] = useState<string | null>(null);
  const [updatingQuad, setUpdatingQuad] = useState<string | null>(null);
  const [verifyingId, setVerifyingId] = useState<string | null>(null);
  const [geocodingId, setGeocodingId] = useState<string | null>(null);
  const [editPinListing, setEditPinListing] = useState<MarketListing | null>(null);
  const [propertyMap, setPropertyMap] = useState<Record<string, string>>({});

  // Fetch properties to build address → id map
  useEffect(() => {
    const fetchProperties = async () => {
      const { data } = await supabase
        .from('properties')
        .select('id, address, display_address');
      if (data) {
        const map: Record<string, string> = {};
        for (const p of data) {
          map[p.address.trim().toLowerCase()] = p.id;
          if (p.display_address) {
            map[p.display_address.trim().toLowerCase()] = p.id;
          }
        }
        setPropertyMap(map);
      }
    };
    fetchProperties();
  }, [listings.length]); // Re-fetch when listings change (new property may have been created)

  // Persist horizontal scroll so returning to the tab (or any remount) doesn't snap back to the left.
  // Note: the actual scrollable element is created inside the shadcn <Table /> wrapper.
  const scrollStorageKey = useMemo(() => {
    // If you want per-page persistence, include page/filter state here.
    // For now, keep it stable for the market listings table.
    return 'market_listings_table_scroll_left_v1';
  }, []);

  const getScrollEl = () => {
    return scrollContainerRef.current?.querySelector(
      '.overflow-auto, [class*="overflow-auto"]'
    ) as HTMLElement | null;
  };

  useEffect(() => {
    const el = getScrollEl();
    if (!el) return;

    const saved = sessionStorage.getItem(scrollStorageKey);
    if (saved) {
      const next = Number(saved);
      if (Number.isFinite(next)) {
        // rAF so layout is ready (table width computed) before applying scrollLeft.
        requestAnimationFrame(() => {
          const el2 = getScrollEl();
          if (el2) el2.scrollLeft = next;
        });
      }
    }

    let rafId: number | null = null;
    const onScroll = () => {
      if (rafId) cancelAnimationFrame(rafId);
      rafId = requestAnimationFrame(() => {
        sessionStorage.setItem(scrollStorageKey, String(el.scrollLeft));
      });
    };

    el.addEventListener('scroll', onScroll, { passive: true });

    return () => {
      if (rafId) cancelAnimationFrame(rafId);
      el.removeEventListener('scroll', onScroll);
      // Ensure we store one last time on unmount
      sessionStorage.setItem(scrollStorageKey, String(el.scrollLeft));
    };
  }, [scrollStorageKey]);

  // Check if listing is stale (not verified in past 30 days)
  const isStale = (listing: MarketListing): boolean => {
    if (!listing.last_verified_date) return true;
    try {
      const verifiedDate = parseISO(listing.last_verified_date);
      return differenceInDays(new Date(), verifiedDate) > 30;
    } catch {
      return true;
    }
  };

  // Mark listing as verified today
  const handleVerify = async (listing: MarketListing) => {
    setVerifyingId(listing.id);
    try {
      const today = format(new Date(), 'yyyy-MM-dd');
      const { error } = await supabase
        .from('market_listings')
        .update({ last_verified_date: today, updated_at: new Date().toISOString() })
        .eq('id', listing.id);

      if (error) throw error;
      toast.success('Listing verified');
      onRefresh();
    } catch (err) {
      console.error('Failed to verify listing:', err);
      toast.error('Failed to verify listing');
    } finally {
      setVerifyingId(null);
    }
  };

  // Reset pin to auto-geocode (clears manual override then re-geocodes)
  const handleResetPin = async (listing: MarketListing) => {
    const accessToken = session?.access_token;
    if (!accessToken) {
      toast.error('Not authenticated');
      return;
    }

    setGeocodingId(listing.id);
    try {
      // Step 1: Clear manual override
      const { error } = await supabase
        .from('market_listings')
        .update({
          latitude: null,
          longitude: null,
          geocode_source: null,
          geocoded_at: null,
        })
        .eq('id', listing.id);
      
      if (error) throw error;

      // Step 2: Immediately re-geocode (which also reassigns submarket)
      const { data, error: geoError } = await supabase.functions.invoke('geocode-market-listing', {
        headers: { Authorization: `Bearer ${accessToken}` },
        body: { listingId: listing.listing_id },
      });

      if (geoError) throw geoError;
      if (data?.error) throw new Error(data.error);

      if (data?.geocoded) {
        const msg = data.submarket_assigned
          ? `Pin & submarket reset — now "${data.submarket}"`
          : 'Pin reset & re-geocoded';
        toast.success(msg);
      } else {
        toast.warning('Pin cleared but auto-geocode returned no results');
      }

      onRefresh();
    } catch (err) {
      console.error('Failed to reset pin:', err);
      toast.error('Failed to reset pin location');
    } finally {
      setGeocodingId(null);
    }
  };

  const handleAutoGeocode = async (listing: MarketListing) => {
    const accessToken = session?.access_token;
    if (!accessToken) {
      toast.error('Not authenticated');
      return;
    }

    setGeocodingId(listing.id);
    try {
      const { data, error } = await supabase.functions.invoke('geocode-market-listing', {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
        body: { listingId: listing.listing_id || listing.id },
      });

      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      if (data?.geocoded) {
        toast.success('Geocode updated');
      } else {
        toast.message(data?.message || 'No changes');
      }

      onRefresh();
    } catch (err) {
      console.error('Failed to auto-geocode:', err);
      toast.error(err instanceof Error ? err.message : 'Failed to auto-geocode');
    } finally {
      setGeocodingId(null);
    }
  };

  // Toggle distribution warehouse flag
  const handleToggleDW = async (listing: MarketListing) => {
    setUpdatingDW(listing.id);
    try {
      const newValue = !listing.is_distribution_warehouse;
      const { error } = await supabase
        .from('market_listings')
        .update({ is_distribution_warehouse: newValue, updated_at: new Date().toISOString() })
        .eq('id', listing.id);

      if (error) throw error;
      onRefresh();
    } catch (err) {
      console.error('Error updating DW flag:', err);
      toast.error('Failed to update');
    } finally {
      setUpdatingDW(null);
    }
  };

  // Cycle Calgary Quad: null → NE → NW → SE → SW → null
  const QUAD_CYCLE = [null, 'NE', 'SE', 'NW', 'SW'] as const;
  const handleCycleQuad = async (listing: MarketListing) => {
    setUpdatingQuad(listing.id);
    try {
      const currentIdx = QUAD_CYCLE.indexOf(listing.calgary_quad as any);
      const nextIdx = (currentIdx + 1) % QUAD_CYCLE.length;
      const newValue = QUAD_CYCLE[nextIdx];
      const { error } = await supabase
        .from('market_listings')
        .update({ calgary_quad: newValue, updated_at: new Date().toISOString() })
        .eq('id', listing.id);

      if (error) throw error;
      onRefresh();
    } catch (err) {
      console.error('Error updating Calgary Quad:', err);
      toast.error('Failed to update');
    } finally {
      setUpdatingQuad(null);
    }
  };

  // Toggle land flag
  const handleToggleLand = async (listing: MarketListing) => {
    setUpdatingLand(listing.id);
    try {
      const newValue = !listing.has_land;
      const { error } = await supabase
        .from('market_listings')
        .update({ has_land: newValue, updated_at: new Date().toISOString() })
        .eq('id', listing.id);

      if (error) throw error;
      onRefresh();
    } catch (err) {
      console.error('Error updating Land flag:', err);
      toast.error('Failed to update');
    } finally {
      setUpdatingLand(null);
    }
  };

  // Sortable header component
  const SortableHeader = ({ column, children, className = '' }: { column: SortableColumn; children: React.ReactNode; className?: string }) => {
    const isActive = sortColumn === column;
    return (
      <TableHead 
        className={`text-background cursor-pointer select-none hover:bg-zinc-600 transition-colors ${className}`}
        onClick={() => onSort(column)}
      >
        <div className="flex items-center gap-1">
          {children}
          {isActive && sortDirection === 'asc' && <ArrowUp className="h-3 w-3" />}
          {isActive && sortDirection === 'desc' && <ArrowDown className="h-3 w-3" />}
          {!isActive && <ArrowUpDown className="h-3 w-3 opacity-40" />}
        </div>
      </TableHead>
    );
  };

  // Smooth keyboard horizontal scroll - trackpad-like experience
  useEffect(() => {
    let animationId: number | null = null;
    let scrollDirection = 0; // -1 for left, 1 for right, 0 for stopped
    let velocity = 0;
    let lastTime = performance.now();
    
    const maxVelocity = 15; // pixels per frame at max speed
    const acceleration = 0.12; // how quickly we reach max speed
    const deceleration = 0.92; // how quickly we slow down

    const animate = (currentTime: number) => {
      // Calculate delta time for frame-rate independent animation
      const deltaTime = Math.min((currentTime - lastTime) / 8.33, 3); // normalize to ~120fps, cap at 3x
      lastTime = currentTime;

      const container = getScrollEl();
      if (!container) {
        animationId = requestAnimationFrame(animate);
        return;
      }

      // Accelerate towards target velocity or decelerate to stop
      if (scrollDirection !== 0) {
        velocity += (scrollDirection * maxVelocity - velocity) * acceleration * deltaTime;
      } else {
        velocity *= Math.pow(deceleration, deltaTime);
      }

      // Apply scroll if there's meaningful velocity
      if (Math.abs(velocity) > 0.1) {
        container.scrollBy({ left: velocity * deltaTime, behavior: 'auto' });
      }

      animationId = requestAnimationFrame(animate);
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isHovered) return;

      if (e.key === 'ArrowLeft') {
        e.preventDefault();
        scrollDirection = -1;
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        scrollDirection = 1;
      } else if (e.key === 'Escape') {
        setSelectedRowId(null);
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') {
        scrollDirection = 0;
      }
    };

    // Start animation loop
    animationId = requestAnimationFrame(animate);

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    
    return () => {
      if (animationId) cancelAnimationFrame(animationId);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [isHovered]);

  return (
    <div 
      ref={scrollContainerRef}
      className="relative"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      role="region"
      aria-label="Market listings table"
    >
      <Table className="min-w-[3000px]" stickyHeader>
        <TableHeader className="sticky top-0 z-40">
          <TableRow className="bg-muted">
            {onToggleSelectAll && (
              <TableHead className="sticky left-0 top-0 z-50 w-10 bg-muted text-muted-foreground shadow-[2px_0_5px_-2px_rgba(0,0,0,0.08)] px-3">
                <Checkbox
                  checked={listings.length > 0 && listings.every(l => selectedIds?.has(l.id))}
                  onCheckedChange={() => onToggleSelectAll(listings.map(l => l.id))}
                  onClick={e => e.stopPropagation()}
                  aria-label="Select all"
                />
              </TableHead>
            )}
            <TableHead className="sticky left-0 top-0 z-50 min-w-[180px] bg-muted text-muted-foreground shadow-[2px_0_5px_-2px_rgba(0,0,0,0.08)]">Address</TableHead>
            <TableHead className="text-muted-foreground min-w-[130px] bg-muted">Submarket</TableHead>
            <TableHead className="text-muted-foreground min-w-[100px] bg-muted">City</TableHead>
            <TableHead className="text-muted-foreground min-w-[80px] bg-muted">Type</TableHead>
            <TableHead className="text-muted-foreground min-w-[70px] bg-muted">
              <Tooltip>
                <TooltipTrigger className="cursor-default">Calg. Quad.</TooltipTrigger>
                <TooltipContent>Calgary Quadrant (NE/NW/SE/SW)</TooltipContent>
              </Tooltip>
            </TableHead>
            <TableHead className="text-muted-foreground min-w-[60px] bg-muted">
              <Tooltip>
                <TooltipTrigger className="cursor-default">DW</TooltipTrigger>
                <TooltipContent>Distribution Warehouse</TooltipContent>
              </Tooltip>
            </TableHead>
            <SortableHeader column="size_sf" className="text-right min-w-[100px] bg-muted">Size (SF)</SortableHeader>
            <TableHead className="text-muted-foreground min-w-[80px] bg-muted">Acres</TableHead>
            <SortableHeader column="warehouse_sf" className="text-right min-w-[110px] bg-muted">Warehouse SF</SortableHeader>
            <SortableHeader column="office_sf" className="text-right min-w-[90px] bg-muted">Office SF</SortableHeader>
            <TableHead className="text-muted-foreground text-right min-w-[90px] bg-muted">Shop SF</TableHead>
            <TableHead className="text-muted-foreground text-right min-w-[90px] bg-muted">Clear Ht</TableHead>
            <SortableHeader column="dock_doors" className="text-right min-w-[70px] bg-muted">Docks</SortableHeader>
            <SortableHeader column="drive_in_doors" className="text-right min-w-[70px] bg-muted">Drive-In</SortableHeader>
            <SortableHeader column="power_amps" className="min-w-[110px] bg-muted">Power</SortableHeader>
            <TableHead className="text-muted-foreground min-w-[90px] bg-muted">Sprinkler</TableHead>
            <TableHead className="text-muted-foreground min-w-[70px] bg-muted">Cranes</TableHead>
            <TableHead className="text-muted-foreground min-w-[60px] bg-muted">Yard</TableHead>
            <TableHead className="text-muted-foreground min-w-[90px] bg-muted">Yard Area</TableHead>
            <TableHead className="text-muted-foreground min-w-[80px] bg-muted">X-Dock</TableHead>
            <TableHead className="text-muted-foreground min-w-[90px] bg-muted">Trailer</TableHead>
            <TableHead className="text-muted-foreground min-w-[80px] bg-muted">Zoning</TableHead>
            <TableHead className="text-muted-foreground min-w-[60px] bg-muted">MUA</TableHead>
            <TableHead className="text-muted-foreground min-w-[90px] bg-muted">Ask Rate</TableHead>
            <TableHead className="text-muted-foreground min-w-[80px] bg-muted">Op Cost</TableHead>
            <TableHead className="text-muted-foreground min-w-[90px] bg-muted">Gross</TableHead>
            <TableHead className="text-muted-foreground min-w-[100px] bg-muted">Sale Price</TableHead>
            <TableHead className="text-muted-foreground min-w-[90px] bg-muted">Sub Exp</TableHead>
            <TableHead className="text-muted-foreground min-w-[90px] bg-muted">Avail</TableHead>
            <TableHead className="text-muted-foreground min-w-[140px] bg-muted">Landlord</TableHead>
            <TableHead className="text-muted-foreground min-w-[140px] bg-muted">Development</TableHead>
            <TableHead className="text-muted-foreground min-w-[140px] bg-muted">Brokerage</TableHead>
            <TableHead className="text-muted-foreground min-w-[180px] bg-muted">Notes</TableHead>
            <TableHead className="text-muted-foreground min-w-[130px] bg-muted">Status</TableHead>
            <SortableHeader column="last_verified_date" className="min-w-[100px] bg-muted">Verified</SortableHeader>
            <TableHead className="text-muted-foreground min-w-[60px] bg-muted">Land</TableHead>
            <TableHead className="sticky right-0 top-0 z-50 min-w-[160px] bg-muted text-muted-foreground shadow-[-2px_0_5px_-2px_rgba(0,0,0,0.08)]">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {listings.map((listing, index) => {
            const isSelected = selectedRowId === listing.id;
            const isEvenRow = index % 2 === 1;
            const stale = isStale(listing);
            // Stale styling - bold red background for unverified listings
            const staleRowBg = stale ? 'bg-red-700 dark:bg-red-800' : '';
            const staleTextClass = stale ? 'text-white' : '';
            // Sticky columns match the rest of the table's striping
            const stickyBg = isSelected 
              ? 'bg-blue-50' 
              : stale
                ? 'bg-red-50 dark:bg-red-900/30'
                : isEvenRow
                  ? 'bg-table-stripe' 
                  : 'bg-card';
            const hoverClass = isSelected 
              ? 'hover:!bg-blue-100' 
              : stale
                ? 'hover:!bg-red-100 dark:hover:!bg-red-800/50'
                : isEvenRow
                  ? 'hover:!bg-slate-100 dark:hover:!bg-slate-800/60'
                  : 'hover:!bg-slate-50 dark:hover:!bg-slate-800/40';
            const stickyHoverClass = isSelected
              ? ''
              : stale
                ? 'group-hover:!bg-red-100 dark:group-hover:!bg-red-800/50'
                : isEvenRow
                  ? 'group-hover:!bg-slate-100 dark:group-hover:!bg-slate-800/60'
                  : 'group-hover:!bg-slate-50 dark:group-hover:!bg-slate-800/40';
            const outlineClass = isSelected
              ? 'outline outline-2 outline-blue-400 dark:outline-blue-500 -outline-offset-1'
              : 'outline-0 hover:outline hover:outline-1 hover:outline-slate-300 dark:hover:outline-slate-600 hover:-outline-offset-1';
            const rowBg = isSelected 
              ? '!bg-blue-50 dark:!bg-blue-950/30' 
              : stale 
                ? '!bg-red-50 dark:!bg-red-900/30' 
                : isEvenRow 
                  ? 'bg-table-stripe' 
                  : '';
            return (
            <TableRow 
              key={listing.id} 
              className={cn(
                'group cursor-pointer transition-all !border-b !border-border',
                rowBg,
                hoverClass,
                outlineClass
              )}
              onClick={() => setSelectedRowId(isSelected ? null : listing.id)}
            >
              {/* Checkbox */}
              {onToggleSelect && (
                <TableCell
                  className={`sticky left-0 z-20 w-10 px-3 shadow-[2px_0_5px_-2px_rgba(0,0,0,0.08)] transition-colors ${stickyBg} ${stickyHoverClass}`}
                  onClick={e => e.stopPropagation()}
                >
                  <Checkbox
                    checked={selectedIds?.has(listing.id) ?? false}
                    onCheckedChange={() => onToggleSelect(listing.id)}
                    aria-label="Select row"
                  />
                </TableCell>
              )}
              {/* Address - Sticky with shadow right border that persists during scroll */}
              <TableCell className={`sticky left-0 z-20 font-medium shadow-[2px_0_5px_-2px_rgba(0,0,0,0.3)] transition-colors ${stickyBg} ${stickyHoverClass}`}>
                <div className="min-w-[180px] max-w-[220px] whitespace-normal break-words leading-tight py-1">
                  {listing.display_address || listing.address}
                </div>
              </TableCell>
              
              {/* Submarket */}
              <TableCell className="text-sm">{formatSubmarket(listing.submarket)}</TableCell>
              
              {/* City */}
              <TableCell className="text-sm">{listing.city || '-'}</TableCell>
              
              {/* Type */}
              <TableCell className="text-sm">{listing.listing_type || '-'}</TableCell>
              
              {/* Calgary Quad */}
              <TableCell>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleCycleQuad(listing);
                  }}
                  disabled={updatingQuad === listing.id}
                  className={`px-2 py-1 text-xs font-semibold rounded border transition-all disabled:opacity-50 ${
                    listing.calgary_quad === 'NE' ? 'bg-orange-100 text-orange-800 border-orange-300'
                    : listing.calgary_quad === 'SE' ? 'bg-lime-100 text-lime-800 border-lime-300'
                    : listing.calgary_quad === 'NW' ? 'bg-cyan-100 text-cyan-800 border-cyan-300'
                    : listing.calgary_quad === 'SW' ? 'bg-yellow-100 text-yellow-800 border-yellow-300'
                    : 'bg-muted text-muted-foreground border-border'
                  }`}
                  style={{ borderRadius: 'var(--radius)' }}
                >
                  {listing.calgary_quad || '-'}
                </button>
              </TableCell>
              
              {/* Distribution Warehouse */}
              <TableCell>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleToggleDW(listing);
                  }}
                  disabled={updatingDW === listing.id}
                  className={`px-2 py-1 text-xs font-semibold rounded border transition-all disabled:opacity-50 ${
                    listing.is_distribution_warehouse 
                      ? 'bg-primary/10 text-primary border-primary/30' 
                      : 'bg-destructive/10 text-destructive border-destructive/30'
                  }`}
                  style={{ borderRadius: 'var(--radius)' }}
                >
                  {listing.is_distribution_warehouse ? 'Y' : 'N'}
                </button>
              </TableCell>
              
              {/* Size */}
              <TableCell className="text-right font-mono text-sm">
              {formatSF(listing.size_sf)}
              </TableCell>
              
              {/* Land Acres */}
              <TableCell className="text-sm">{listing.land_acres || '-'}</TableCell>
              
              {/* Warehouse SF */}
              <TableCell className="text-right font-mono text-sm">
                {listing.warehouse_sf ? listing.warehouse_sf.toLocaleString() : '-'}
              </TableCell>
              
              {/* Office SF */}
              <TableCell className="text-right font-mono text-sm">
                {listing.office_sf ? listing.office_sf.toLocaleString() : '-'}
              </TableCell>
              
              {/* Shop SF */}
              <TableCell className="text-right font-mono text-sm">
                {listing.shop_sf ? listing.shop_sf.toLocaleString() : '-'}
              </TableCell>
              
              {/* Clear Height */}
              <TableCell className="text-right text-sm">
                {listing.clear_height_ft ? `${listing.clear_height_ft}'` : '-'}
              </TableCell>
              
              {/* Dock Doors */}
              <TableCell className="text-right text-sm">
                {listing.dock_doors ?? '-'}
              </TableCell>
              
              {/* Drive-In Doors */}
              <TableCell className="text-right text-sm">
                {listing.drive_in_doors ?? '-'}
              </TableCell>
              
              {/* Power (Amps / Voltage combined) */}
              <TableCell className="text-sm">
                {listing.power_amps || listing.voltage
                  ? `${listing.power_amps || '–'}A / ${listing.voltage || '–'}V`
                  : '-'}
              </TableCell>
              
              {/* Sprinkler */}
              <TableCell className="text-sm">{listing.sprinkler || '-'}</TableCell>
              
              {/* Cranes - Y/N based on whether values exist */}
              <TableCell className="text-sm">{(listing.cranes || listing.crane_tons) ? 'Y' : 'N'}</TableCell>
              
              {/* Yard */}
              <TableCell className="text-sm">{listing.yard || '-'}</TableCell>
              
              {/* Yard Area */}
              <TableCell className="text-sm">{listing.yard_area || '-'}</TableCell>
              
              {/* Cross-Dock */}
              <TableCell className="text-sm">{listing.cross_dock || '-'}</TableCell>
              
              {/* Trailer Parking */}
              <TableCell className="text-sm">{listing.trailer_parking || '-'}</TableCell>
              
              {/* Zoning */}
              <TableCell className="text-sm">{listing.zoning || '-'}</TableCell>
              
              {/* MUA */}
              <TableCell className="text-sm">{listing.mua || '-'}</TableCell>
              
              {/* Asking Rate */}
              <TableCell className="text-sm">{formatCurrency(listing.asking_rate_psf)}</TableCell>
              
              {/* Op Costs */}
              <TableCell className="text-sm">{formatCurrency(listing.op_costs)}</TableCell>
              
              {/* Gross Rate - Calculated from Ask + Op Cost */}
              <TableCell className="text-sm">{calculateGrossRate(listing.asking_rate_psf, listing.op_costs)}</TableCell>
              
              {/* Sale Price - Currency formatted */}
              <TableCell className="text-sm">{formatSalePrice(listing.sale_price)}</TableCell>
              
              {/* Sublease Exp */}
              <TableCell className="text-sm">{listing.sublease_exp || '-'}</TableCell>
              
              {/* Availability */}
              <TableCell className="text-sm">{formatDate(listing.availability_date)}</TableCell>
              
              {/* Landlord */}
              <TableCell>
                <div className="truncate max-w-[130px] text-sm" title={listing.landlord || ''}>
                  {listing.landlord || '-'}
                </div>
              </TableCell>

              {/* Development */}
              <TableCell>
                <div className="truncate max-w-[130px] text-sm" title={(listing as any).development_name || ''}>
                  {(listing as any).development_name || '-'}
                </div>
              </TableCell>
              
              {/* Broker */}
              <TableCell>
                <div className="truncate max-w-[130px] text-sm" title={listing.broker_source || ''}>
                  {listing.broker_source || '-'}
                </div>
              </TableCell>
              
              {/* Notes */}
              <TableCell>
                <div className="truncate max-w-[170px] text-sm text-muted-foreground" title={listing.notes_public || ''}>
                  {listing.notes_public || '-'}
                </div>
              </TableCell>
              
              {/* Status - Near end since most are Active until transaction */}
              <TableCell>
                <StatusDropdown
                  listing={listing}
                  onStatusChanged={onRefresh}
                />
              </TableCell>
              
              {/* Last Verified */}
              <TableCell className="text-sm">
                {listing.last_verified_date 
                  ? format(parseISO(listing.last_verified_date), 'MMM d, yyyy')
                  : <span className="text-white/80 font-medium">Never</span>
                }
              </TableCell>
              
              {/* Land Toggle */}
              <TableCell>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleToggleLand(listing);
                  }}
                  disabled={updatingLand === listing.id}
                  className={`px-2 py-1 text-xs font-semibold rounded border transition-all disabled:opacity-50 ${
                    listing.has_land 
                      ? 'bg-amber-100 text-amber-800 border-amber-300' 
                      : 'bg-muted text-muted-foreground border-border'
                  }`}
                  style={{ borderRadius: 'var(--radius)' }}
                >
                  {listing.has_land ? 'Y' : 'N'}
                </button>
              </TableCell>
              
              {/* Actions - Sticky with shadow left border that persists during scroll */}
              <TableCell className={`sticky right-0 z-20 shadow-[-2px_0_5px_-2px_rgba(0,0,0,0.3)] transition-colors ${stickyBg} ${stickyHoverClass}`}>
                <div className="flex items-center gap-0.5">
                  {/* Geo Dropdown */}
                  <DropdownMenu>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <DropdownMenuTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            className={cn(
                              "h-7 w-7 relative",
                              listing.geocode_source === 'manual' && "ring-2 ring-warning ring-offset-1"
                            )}
                            onClick={(e) => e.stopPropagation()}
                          >
                            {listing.latitude && listing.longitude ? (
                              <>
                                <MapPin className={cn(
                                  "h-3.5 w-3.5",
                                  listing.geocode_source === 'manual' ? "text-warning" : "text-green-600"
                                )} />
                                {listing.geocode_source === 'manual' && (
                                  <Hand className="w-2 h-2 absolute -top-0.5 -right-0.5 text-warning" />
                                )}
                              </>
                            ) : (
                              <MapPinOff className="h-3.5 w-3.5 text-muted-foreground" />
                            )}
                          </Button>
                        </DropdownMenuTrigger>
                      </TooltipTrigger>
                      <TooltipContent>Geocode</TooltipContent>
                    </Tooltip>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={(e) => { e.stopPropagation(); setEditPinListing(listing); }}>
                        <Pencil className="w-4 h-4 mr-2" />
                        Edit pin location
                      </DropdownMenuItem>
                      {listing.geocode_source !== 'manual' && (
                        <DropdownMenuItem
                          onClick={(e) => { e.stopPropagation(); handleAutoGeocode(listing); }}
                          disabled={geocodingId === listing.id}
                        >
                          <MapPin className="w-4 h-4 mr-2" />
                          {geocodingId === listing.id ? 'Auto-geocoding…' : 'Auto-geocode now'}
                        </DropdownMenuItem>
                      )}
                      {listing.geocode_source === 'manual' && (
                        <DropdownMenuItem onClick={(e) => { e.stopPropagation(); handleResetPin(listing); }}>
                          <RotateCcw className="w-4 h-4 mr-2" />
                          Reset to auto-geocode
                        </DropdownMenuItem>
                      )}
                    </DropdownMenuContent>
                  </DropdownMenu>

                  {/* Verify */}
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant={stale ? "default" : "ghost"}
                        size="icon"
                        className={cn("h-7 w-7", stale && "bg-green-600 hover:bg-green-700 text-white")}
                        onClick={(e) => { e.stopPropagation(); handleVerify(listing); }}
                        disabled={verifyingId === listing.id}
                      >
                        <CheckCircle className="h-3.5 w-3.5" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>Verify Listing</TooltipContent>
                  </Tooltip>

                  {/* Edit */}
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7"
                        onClick={(e) => { e.stopPropagation(); onEdit(listing); }}
                      >
                        <Pencil className="h-3.5 w-3.5" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>Edit Listing</TooltipContent>
                  </Tooltip>

                  {/* Kebab — Link, Duplicate, Log Transaction, Property Link */}
                  <DropdownMenu>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <DropdownMenuTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-7 w-7"
                            onClick={(e) => e.stopPropagation()}
                          >
                            <MoreHorizontal className="h-3.5 w-3.5" />
                          </Button>
                        </DropdownMenuTrigger>
                      </TooltipTrigger>
                      <TooltipContent>More</TooltipContent>
                    </Tooltip>
                    <DropdownMenuContent align="end">
                      {(listing.brochure_link || listing.link) ? (
                        <DropdownMenuItem asChild>
                          <a
                            href={(listing.brochure_link || listing.link)!}
                            target="_blank"
                            rel="noopener noreferrer"
                            onClick={(e) => e.stopPropagation()}
                          >
                            <ExternalLink className="w-4 h-4 mr-2" />
                            Open Link
                          </a>
                        </DropdownMenuItem>
                      ) : (
                        <DropdownMenuItem disabled>
                          <ExternalLink className="w-4 h-4 mr-2" />
                          No Link
                        </DropdownMenuItem>
                      )}
                      {onDuplicate && (
                        <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onDuplicate(listing); }}>
                          <Copy className="w-4 h-4 mr-2" />
                          Duplicate
                        </DropdownMenuItem>
                      )}
                      <DropdownMenuItem onClick={(e) => {
                        e.stopPropagation();
                        localStorage.setItem('lease-comp-prefill', JSON.stringify({
                          address: listing.address,
                          size_sf: listing.size_sf,
                          submarket: listing.submarket,
                        }));
                        navigate('/lease-comps/new');
                      }}>
                        <Receipt className="w-4 h-4 mr-2" />
                        Log Lease Comp
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      {(() => {
                        const propertyId = propertyMap[listing.address.trim().toLowerCase()];
                        return propertyId ? (
                          <DropdownMenuItem onClick={(e) => { e.stopPropagation(); navigate(`/properties/${propertyId}`); }}>
                            <Building2 className="w-4 h-4 mr-2" />
                            View Property
                          </DropdownMenuItem>
                        ) : (
                          <DropdownMenuItem disabled>
                            <Building2 className="w-4 h-4 mr-2" />
                            No Property
                          </DropdownMenuItem>
                        );
                      })()}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </TableCell>
            </TableRow>
          );})}
        </TableBody>
      </Table>

      {/* Edit Pin Location Dialog */}
      <EditMarketPinDialog
        listing={editPinListing}
        open={editPinListing !== null}
        onOpenChange={(open) => {
          if (!open) setEditPinListing(null);
        }}
        onSave={() => {
          setEditPinListing(null);
          onRefresh();
        }}
      />

    </div>
  );
}
